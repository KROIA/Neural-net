#include "maptile.h"

Maptile::Maptile()
{

}
Maptile::~Maptile()
{

}
